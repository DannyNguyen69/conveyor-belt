# bang_chuyen > 2025-07-21 8:49pm
https://universe.roboflow.com/thuan-bang-chuyen/bang_chuyen-froqu

Provided by a Roboflow user
License: CC BY 4.0

