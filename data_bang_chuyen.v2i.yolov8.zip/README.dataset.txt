# data_bang_chuyen > 2025-07-29 5:13pm
https://universe.roboflow.com/thuan-bang-chuyen/data_bang_chuyen-6lpyr

Provided by a Roboflow user
License: CC BY 4.0

